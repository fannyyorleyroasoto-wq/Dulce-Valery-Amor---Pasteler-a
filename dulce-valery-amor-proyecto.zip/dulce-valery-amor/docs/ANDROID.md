# Android y APK

## Instalar como app (sin APK)
1. Publica la web en Render con HTTPS.
2. Abre la URL en Chrome para Android.
3. Menú ⋮ → **Instalar aplicación** o **Añadir a pantalla de inicio**.

## Compilar APK nativo con Capacitor
Requisitos: Node.js, Android Studio y Android SDK.

1. En `package.json`, agrega dependencias `@capacitor/core` y `@capacitor/android`, y dependencia de desarrollo `@capacitor/cli`.
2. Crea `capacitor.config.ts` con `appId: 'cl.dulcevaleryamor.app'`, `appName: 'Dulce Valery Amor'` y `webDir: 'public'`.
3. Ejecuta `npx cap add android` y `npx cap sync android`.
4. Ejecuta `npx cap open android`; en Android Studio usa Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Para Google Play normalmente necesitarás un Android App Bundle (.aab), firma de publicación, ficha de tienda y cumplir las políticas vigentes.

Nota: esta es una guía; la compilación requiere herramientas Android que no están incluidas en este ZIP.
