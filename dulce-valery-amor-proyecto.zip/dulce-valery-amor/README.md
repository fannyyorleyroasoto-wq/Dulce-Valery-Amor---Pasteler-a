# Dulce Valery Amor

Proyecto inicial de pastelería con catálogo, carrito, pedidos por WhatsApp, formulario de torta personalizada, administración local y PWA instalable.

## Ejecutar localmente
1. Instala Node.js 18 o superior.
2. En esta carpeta ejecuta `npm install`.
3. Ejecuta `npm start`.
4. Abre `http://localhost:3000`.

## Publicar en Render desde GitHub
1. Crea un repositorio nuevo llamado `dulce-valery-amor`.
2. Sube todos los archivos y carpetas de este proyecto a la raíz del repositorio.
3. En Render crea un **Web Service** y conecta ese repositorio.
4. Usa Build Command `npm install` y Start Command `npm start`. `render.yaml` incluye esos valores.
5. Cuando Render indique Live, abre la URL pública HTTPS.

## Configuración inicial
- En la app abre **Admin**.
- Contraseña inicial: `Valery2026!`; cámbiala en Configuración de la tienda.
- Configura el WhatsApp con código de país y solo dígitos (ejemplo de formato chileno: `56912345678`). No escribas `+`, espacios ni guiones.
- Precios iniciales son ejemplos en CLP; modifícalos en Admin.
- Exporta un respaldo JSON periódicamente.

## Android / APK
La app es una PWA y se puede instalar desde el navegador Android una vez publicada por HTTPS: abre la web en Chrome y usa el menú **Instalar aplicación** o **Añadir a pantalla de inicio** (la opción depende del navegador).

Para crear un APK nativo, hace falta envolverla con Capacitor y compilar con Android Studio/Android SDK. Este ZIP **no incluye un APK ya compilado** ni una publicación en Google Play. Ver `docs/ANDROID.md`.

## Limitaciones importantes de esta versión
- Productos, carrito, contraseña y ajustes se guardan en `localStorage` del navegador. No se sincronizan automáticamente entre clientes/dispositivos y limpiar los datos del navegador puede borrarlos.
- La pantalla Admin tiene una contraseña local demostrativa, no autenticación segura de servidor. No publiques datos sensibles ni la uses como administración multiusuario real.
- Los pedidos se redactan y se abren en WhatsApp; la persona debe enviarlos desde WhatsApp. No se cobra en línea.
- Antes de usarla comercialmente con varios dispositivos, añade API/base de datos persistente y autenticación segura del administrador.
