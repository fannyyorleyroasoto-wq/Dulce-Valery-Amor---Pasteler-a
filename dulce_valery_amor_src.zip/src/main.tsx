import React from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  return (
    <main className="page">
      <section className="hero">
        <div className="heart" aria-hidden="true">♥</div>
        <p className="eyebrow">Pastelería artesanal</p>
        <h1>Dulce Valery Amor</h1>
        <p className="intro">Tortas, dulces y momentos hechos con amor.</p>
        <a className="order" href="https://wa.me/56936671794" target="_blank" rel="noreferrer">
          Pedir por WhatsApp
        </a>
      </section>
      <section className="welcome">
        <h2>Un detalle dulce para cada ocasión</h2>
        <p>Muy pronto encontrarás aquí nuestro catálogo de tortas, bollería laminada, tartas y pie.</p>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
